from flask import Flask,request,render_template
import pickle
import numpy as np
import pandas as pd
from joblib import load
# clf_loaded = 

app=Flask(__name__)


@app.route('/index.html')
def home():
    return render_template("index.html")

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/about.html')
def about():
    return render_template("about.html")


@app.route('/blog-details.html')
def blog_details():
    return render_template("blog-details.html")


@app.route('/blog.html')
def blog():
    return render_template("blog.html")


@app.route('/contact.html')
def contact():
    return render_template("contact.html")

@app.route('/project-details.html')
def project_details():
    return render_template("project-details.html")

@app.route('/projects.html')
def projects():
    return render_template("projects.html")


@app.route('/services.html')
def services():
    return render_template("services.html")

if __name__ == "__main__":
    
    app.run(debug = True,port = 8000)
